# Passwortgeschützte PDFs zum Knacken

Dieses Verzeichnis enthält 13 passwortgeschützte PDF-Dateien, die erstellt wurden, um das Knacken von Passwörtern zu üben. Die PDFs enthalten verschiedene Memes und sind eine unterhaltsame Möglichkeit, die Sicherheit von Passwörtern zu demonstrieren.

## Inhalt

- **13 PDF-Dateien**: Jede PDF enthält ein Bild und ist passwortgeschützt.
- **Passwortschutz**:
  - Die ersten 5 PDFs können mit einem Wörterbuchangriff geknackt werden.
  - Die restlichen 8 PDFs sind mit zufälligen Passwörtern geschützt und sollten mit einem Brute-Force-Angriff geknackt werden.

## Verwendung

1. Klone das Repository oder lade die ZIP-Datei herunter.
2. Entpacke die Dateien, falls erforderlich.
3. Versuche, die PDFs zu öffnen, indem du die Passwörter mit John the Ripper knackst.

## Hinweise

- Die Passwörter für die ersten 5 PDFs stammen aus einem Wörterbuch und sind relativ einfach zu erraten.
- Die Passwörter für die restlichen PDFs sind zufällig generiert und erfordern einen Brute-Force-Angriff.

Viel Spaß beim Knacken der Passwörter! 